{{-- resources/views/filament/resources/evento-resource/pages/list-eventos.blade.php --}}
<x-filament-panels::page>
    <x-filament-tables::container>
        {{ $this->table }}
    </x-filament-tables::container>
</x-filament-panels::page>