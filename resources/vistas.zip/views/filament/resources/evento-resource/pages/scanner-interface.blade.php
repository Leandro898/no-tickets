<x-filament-panels::page>
    <x-slot name="header">
        <h2 class="text-xl font-semibold text-gray-900 dark:text-white">
            {{ $this->getTitle() }}
        </h2>
    </x-slot>

    {{-- ¡Aquí es donde inyectas tu componente Livewire QrScanner! --}}
    @livewire('qr-scanner')

</x-filament-panels::page>