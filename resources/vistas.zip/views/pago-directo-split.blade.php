@extends('layouts.app')

@section('content')
<script src="https://sdk.mercadopago.com/js/v2"></script>

<div class="max-w-xl mx-auto py-10 px-4 bg-white shadow rounded">
    <h1 class="text-2xl font-bold mb-6">Pago directo con tarjeta - {{ $evento->nombre }}</h1>

    @if ($errors->any())
        <div class="bg-red-100 text-red-800 p-4 rounded mb-6">
            <ul class="list-disc pl-5">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form id="payment-form" method="POST" action="{{ route('eventos.pago.directo.store', $evento) }}">
        @csrf
        <input type="hidden" name="token" id="token">

        <div class="mb-4">
            <label class="block mb-1 font-medium">Nombre completo</label>
            <input type="text" name="nombre" class="w-full border rounded p-2" required>
        </div>

        <div class="mb-4">
            <label class="block mb-1 font-medium">Email</label>
            <input type="email" name="email" class="w-full border rounded p-2" required>
        </div>

        <div class="mb-4">
            <label class="block mb-1 font-medium">Documento (DNI)</label>
            <input type="text" name="identification_number" class="w-full border rounded p-2" required>
            <input type="hidden" name="identification_type" value="DNI">
        </div>

        <div id="cardForm" class="mb-4 space-y-4">
            <div>
                <label class="block mb-1 font-medium">Número de tarjeta</label>
                <div id="cardNumber" class="border rounded p-2"></div>
            </div>

            <div>
                <label class="block mb-1 font-medium">Fecha de expiración</label>
                <div id="expirationDate" class="border rounded p-2"></div>
            </div>

            <div>
                <label class="block mb-1 font-medium">Código de seguridad</label>
                <div id="securityCode" class="border rounded p-2"></div>
            </div>

            <div>
                <label class="block mb-1 font-medium">Banco</label>
                <select id="issuer" name="issuer_id" class="w-full border rounded p-2"></select>
            </div>

            <div>
                <label class="block mb-1 font-medium">Cuotas</label>
                <select id="installments" name="installments" class="w-full border rounded p-2"></select>
            </div>
        </div>

        <input type="hidden" name="payment_method_id" id="paymentMethodId">
        <input type="hidden" name="monto" value="500">

        <button type="submit" class="mt-6 w-full bg-green-600 text-white py-2 rounded hover:bg-green-700">Pagar $500</button>
    </form>
</div>

<script>
    const mp = new MercadoPago("{{ config('mercadopago.public_key') }}", { locale: 'es-AR' });

    const cardForm = mp.cardForm({
        amount: "500",
        autoMount: true,
        form: {
            id: "payment-form",
            cardNumber: { id: "cardNumber" },
            expirationDate: { id: "expirationDate" },
            securityCode: { id: "securityCode" },
            cardholderName: { id: "nombre" },
            issuer: { id: "issuer" },
            installments: { id: "installments" },
        },
        callbacks: {
            onFormMounted: error => {
                if (error) console.warn("Form mounted with error: ", error);
            },
            onSubmit: event => {
                event.preventDefault();
                cardForm.createCardToken().then(result => {
                    if (result.error) return alert("Token error");
                    document.getElementById('token').value = result.token;
                    event.target.submit();
                });
            },
            onIdentificationTypesReceived: () => {}
        }
    });
</script>
@endsection

