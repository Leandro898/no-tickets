<?php

namespace App\Filament\Resources\EventoResource\Pages;

use App\Filament\Resources\EventoResource;
use Filament\Resources\Pages\Page;
use Filament\Tables\Contracts\HasTable;
use Filament\Tables\Concerns\InteractsWithTable;
use Illuminate\Database\Eloquent\Builder;
use Filament\Tables;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Actions\Action;
use Filament\Tables\Actions\ActionGroup;
use Filament\Tables\Table;
use App\Models\PurchasedTicket;
use App\Mail\TicketsPurchasedMail;
use Illuminate\Support\Facades\Mail;
use Filament\Notifications\Notification;
use Filament\Tables\Actions\Action   as TableAction; // ← para el menú de cada fila
use Filament\Actions\Action          as PageAction;  // ← para el header
use Filament\Forms\Components\Toggle;
use Filament\Tables\Columns\SelectColumn;
use Filament\Tables\Columns\ToggleColumn;


class ListaDigital extends Page implements HasTable
{
    use InteractsWithTable;

    protected static string $resource = EventoResource::class;
    protected static string $view     = 'filament.resources.evento-resource.pages.lista-digital';

    protected $listeners = ['reenviarEntrada', 'toggleEstado'];

    public int $record;

    /* ---------- Básico ---------- */

    public function getTitle(): string
    {
        return 'Lista Digital';
    }

    public function getBreadcrumbs(): array
    {
        return []; // oculta migas
    }

    /* ---------- Query ---------- */

    public function getTableQuery(): Builder
    {
        return PurchasedTicket::query()
            ->whereHas('entrada', fn($q) => $q->where('evento_id', $this->record));
    }

    /* ---------- Columnas ---------- */

    protected function getTableColumns(): array
    {
        return [
            //TextColumn::make('id')->label('ID de Entrada'),
            TextColumn::make('buyer_name')->label('Nombre')->searchable(),
            //TextColumn::make('ticket_type')->label('Tipo'),
            TextColumn::make('order.buyer_email')->label('Email'),
            TextColumn::make('cantidad')
                ->label('Cant.')
                ->getStateUsing(fn($record) => count(json_decode($record->order->items_data, true))),
            TextColumn::make('order.total_amount')->label('Monto Total')
                ->formatStateUsing(fn($state) => '$' . number_format($state, 2, ',', '.')),
            TextColumn::make('order.payment_status')
                ->label('Estado Pedido')
                ->badge()
                ->formatStateUsing(fn($state) => [
                    'paid' => 'Pagado',
                    'pending' => 'Pendiente',
                    'failed' => 'Fallido',
                ][$state] ?? ucfirst($state))
                ->color(fn($state) => match ($state) {
                    'paid' => 'success',
                    'pending' => 'warning',
                    'failed' => 'danger',
                    default => 'secondary',
                })
            // Solo si querés forzar color sólido (opcional):
                ->extraAttributes(['class' => ''])
            // TextColumn::make('Detalles')
            //     ->action(
            //         Action::make('verDetalles')
            //             ->modalHeading('Detalles del cliente')
            //             ->modalContent(fn($record) => view('filament.resources.evento-resource.pages.partials.detalle-modal', ['record' => $record]))
            //             ->modalWidth('lg')
            //             ->requiresConfirmation() // Esto muestra el modal
            //             ->action(function ($record) {
            //                 // Aquí puedes manejar alguna lógica adicional si quieres
            //             }),
            //     )
            // EL MANEJO DE ESTADO DE TICKETS ES PARA FUTURAS VERSIONES PORQUE ESO SOLAMENTE APLICA CUANDO SE VENDEN ENTRADAS INDIVIDUALES COMO EN EVENTIN
            // SelectColumn::make('status')
            //     ->label('Estado')
            //     ->options([
            //         'valid' => 'Valido',
            //         'used' => 'Utilizado',
            //         //'invalid' => 'Invalido', - Opcion por si es necesario en el futuro
            //         // agrega los que necesites
            //     ])
            //     ->sortable()
            //     ->selectablePlaceholder(false)
            //     ->searchable()
            //     ->default('valid'),

        ];
    }

    protected function getTableSearchableColumns(): array
    {
        return [
            Tables\Columns\TextColumn::make('buyer_name'),
            Tables\Columns\TextColumn::make('ticket_type'),
        ];
    }

    /* ---------- Acciones por fila ---------- */

    protected function getTableActions(): array
    {
        return [
            ActionGroup::make([
                Action::make('reenviar_email')
                    ->label('Reenviar por Email')
                    ->icon('heroicon-o-envelope')
                    ->requiresConfirmation()
                    ->modalHeading('Reenviar entradas')
                    ->modalDescription('')
                    ->modalSubmitActionLabel('Si, enviar')
                    ->modalCancelActionLabel('Cancelar')
                    ->modalIcon('heroicon-o-envelope')
                    ->action(fn(PurchasedTicket $ticket) => $this->reenviarEntrada($ticket)),

                Action::make('reenviar_whatsapp')
                    ->label('Enviar por WhatsApp')
                    ->icon('heroicon-o-phone')
                    ->url(
                        fn($record) =>
                        'https://wa.me/' . preg_replace('/\D/', '', $record->order->buyer_phone) .
                            '?text=' . urlencode("Hola {$record->order->buyer_name}, gracias por tu compra. Aquí está tu entrada: " . asset('storage/' . $record->qr_path))
                    )
                    ->openUrlInNewTab(),
            ])
                ->label('Acciones')
                ->color('warning')
                ->button(),
        ];
    }

    /* ---------- Config visual de la tabla ---------- */

    protected function configureTable(Table $table): void
    {
        $table
            ->heading('Lista Digital de Tickets')
            ->description('Control y validación de entradas')
            ->striped()                                 // zebra
            ->paginated([10, 25])                       // solo 10 / 25
            ->defaultPaginationPageOption(25)           // 25 por defecto
            ->defaultSort('id', 'desc')
            ->searchPlaceholder('Buscar por nombre o email...');
    }

    /* ---------- Métodos auxiliares ---------- */

    
    public function reenviarEntrada(PurchasedTicket $ticket): void
    {
    //     dd([
    //     'mail.default'    => config('mail.default'),
    //     'smtp settings'   => config('mail.mailers.smtp'),
    // ]);
    
        $ticket->load('order');

        $email = $ticket->order?->buyer_email;

        if (empty($email)) {
            Notification::make()
                ->title('Sin email de comprador')
                ->warning()
                ->send();

            return;
        }

        Mail::to($email)
            ->send(new TicketsPurchasedMail($ticket->order, [$ticket]));

        Notification::make()
            ->title('Entrada reenviada')
            ->body("El email con las entradas fue reenviado a {$email}")
            ->success()
            ->send();

        $this->dispatch('$refresh');
    }



    public function toggleEstado($ticketId): void
    {
        if ($ticket = PurchasedTicket::find($ticketId)) {
            $ticket->update([
                'status' => $ticket->status === 'valid' ? 'used' : 'valid',
            ]);
        }

        $this->dispatch('$refresh');
    }

    /*------------- Botón “Volver a detalles” -------------*/
    protected function getHeaderActions(): array // (en v3 sigue llamándose así para Page)
    {
        return [
            PageAction::make('volver')
                ->label('Ir a detalles')
                ->icon('heroicon-o-arrow-left')
                ->url(
                    EventoResource::getUrl('detalles', ['record' => $this->record])
                )
                ->color('primary')
                ->button()
                ->extraAttributes(['class' => 'fi-btn-color-primary']),
        ];
    }
}
