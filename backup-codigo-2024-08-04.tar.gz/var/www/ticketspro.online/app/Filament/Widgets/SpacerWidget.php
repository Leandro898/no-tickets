<?php

namespace App\Filament\Widgets;

use Filament\Widgets\Widget;

class SpacerWidget extends Widget
{
    protected static string $view = 'filament.widgets.spacer-widget';
}
