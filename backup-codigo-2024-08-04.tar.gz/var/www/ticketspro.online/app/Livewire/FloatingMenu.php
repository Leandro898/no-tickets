<?php

namespace App\Livewire;

use Livewire\Component;

class FloatingMenu extends Component
{
    public function render()
    {
        return view('livewire.floating-menu');
    }
}
