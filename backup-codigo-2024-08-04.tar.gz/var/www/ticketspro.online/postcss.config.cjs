module.exports = {
    plugins: {
        'postcss-import': {}, // Permite resolver @import en CSS
        tailwindcss: {},      // Procesa las directivas de Tailwind
        autoprefixer: {},     // Añade prefijos de navegador
    },
};