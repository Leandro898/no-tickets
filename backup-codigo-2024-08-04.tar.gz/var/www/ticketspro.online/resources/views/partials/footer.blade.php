<footer class="bg-gray-800 text-gray-300 py-6">
    <div class="container mx-auto px-4 text-center">
      <p>© {{ date('Y') }} Innova Ticket. Todos los derechos reservados.</p>
      <nav class="mt-2 space-x-4">
        <a href="#" class="hover:text-white">Política de privacidad</a>
        <a href="#" class="hover:text-white">Términos de uso</a>
        <a href="#" class="hover:text-white">Contacto</a>
      </nav>
    </div>
  </footer>