@extends('layouts.livewire-test')

@section('content')
    {{-- Invoca TestCounter con su kebab-case correcto --}}
    <livewire:test-counter />
@endsection
