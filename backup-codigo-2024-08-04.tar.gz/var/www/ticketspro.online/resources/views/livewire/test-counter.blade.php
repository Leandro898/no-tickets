<div class="p-4">
    <button type="button" wire:click="increment">Increment</button>
    <h1>{{ $count }}</h1>
</div>
