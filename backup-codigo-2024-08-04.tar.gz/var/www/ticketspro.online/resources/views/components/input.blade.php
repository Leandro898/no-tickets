<input {{ $attributes->merge(['class' => '
    border-gray-300
    focus:border-purple-700
    focus:ring-2
    focus:ring-purple-200
    focus:ring-opacity-50
    rounded-lg
    shadow-sm
    transition
    duration-150
    ease-in-out
']) }}>
