{{-- resources/views/components/authentication-card-logo.blade.php --}}
<div class="mb-6">
    <x-application-logo class="w-20 h-20 fill-current text-purple-700" />
</div>
