{{-- resources/views/components/guest-layout.blade.php --}}
<x-app-layout>
    {{ $slot }}
</x-app-layout>
