<!DOCTYPE html>
<html>
<head>
    <title>Correo de prueba</title>
</head>
<body>
    <h1>{{ $data['title'] }}</h1>
    <p>{{ $data['body'] }}</p>
    <p>Gracias.</p>
</body>
</html>
