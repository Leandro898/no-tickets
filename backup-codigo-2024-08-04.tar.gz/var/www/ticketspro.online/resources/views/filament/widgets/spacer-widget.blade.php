{{-- ¡Solo un div con la altura que quieras! --}}
<div class="w-full h-24"></div>
 {{-- 4rem de espacio --}}
