<x-filament-panels::page>
    <x-slot name="header">
        <h2 class="text-xl font-semibold text-gray-900">
            {{ $this->getTitle() }}
        </h2>
    </x-slot>

    {{-- ¡Aquí es donde inyectas tu componente Livewire QrScanner! --}}
    

</x-filament-panels::page>