<div>
    <p><strong>Nombre:</strong> {{ $record->nombre }}</p>
    <p><strong>Email:</strong> {{ $record->email }}</p>
    <p><strong>Cantidad:</strong> {{ $record->cantidad }}</p>
    <p><strong>Monto total:</strong> ${{ $record->monto_total }}</p>
    <p><strong>Estado pedido:</strong> {{ $record->estado_pedido }}</p>
</div>
