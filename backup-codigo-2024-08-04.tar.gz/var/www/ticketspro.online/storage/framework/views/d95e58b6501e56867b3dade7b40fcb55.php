<?php if (! $__env->hasRenderedOnce('61c126b0-f4a9-4a29-9c30-a5c615c782ee')): $__env->markAsRenderedOnce('61c126b0-f4a9-4a29-9c30-a5c615c782ee'); ?>
    <?php $__env->startPush('styles'); ?>
        <style>
            @media (min-width: 768px) {
                .logo-mobile {
                    display: none;
                }
            }
        </style>
    <?php $__env->stopPush(); ?>
<?php endif; ?>

<div class="logo-mobile flex items-center pl-4 font-bold text-lg text-primary-600">
    <a href="<?php echo e(url('/admin/eventos')); ?>">
        Tickets Pro
    </a>
</div>
<?php /**PATH /var/www/ticketspro.online/resources/views/components/logo-mobile.blade.php ENDPATH**/ ?>