<?php $__env->startSection('body-class', 'bg-gradient-to-br from-purple-50 to-purple-100'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex items-center justify-center min-h-screen px-4 py-12">
  <div class="bg-white rounded-3xl shadow-lg w-full max-w-md p-8">
    <h1 class="text-3xl font-extrabold text-purple-700 mb-6 text-center">
      Establecer contraseña
    </h1>

    
    <?php if(session('status')): ?>
      <div class="mb-4 p-4 bg-green-100 text-green-800 rounded-lg">
        <?php echo e(session('status') === 'passwords.sent'
           ? '¡Enlace para recuperar tu contraseña enviado con éxito!
           Revisa tu Email'
           : session('status')); ?>

      </div>
    <?php endif; ?>

    
    <form method="POST" action="<?php echo e(route('password.email')); ?>" class="space-y-4">
      <?php echo csrf_field(); ?>

      <div>
        <label for="email" class="block text-gray-700 mb-1">Email registrado</label>
        <input id="email" name="email" type="email" required autofocus
               class="w-full rounded-lg border border-gray-300 px-4 py-2
                      focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent" />
      </div>

      <button type="submit"
              class="w-full bg-purple-600 hover:bg-purple-700 text-white font-semibold
                     py-2 rounded-lg shadow transition">
        Enviar enlace
      </button>
    </form>

    <div class="mt-4 text-center">
      <a href="<?php echo e(route('login')); ?>"
         class="text-purple-700 hover:underline text-sm">
        ← Volver a Ingresar
      </a>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/ticketspro.online/resources/views/auth/forgot-password.blade.php ENDPATH**/ ?>