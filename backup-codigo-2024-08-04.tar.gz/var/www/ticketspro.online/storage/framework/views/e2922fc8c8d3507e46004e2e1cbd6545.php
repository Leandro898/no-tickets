<?php $__env->startSection('title', 'Crear cuenta'); ?>

<?php $__env->startSection('body-class', 'bg-gradient-to-br from-purple-50 to-purple-100 overflow-y-scroll'); ?>

<?php $__env->startSection('content'); ?>
<div x-data="{ role: 'cliente', loading: false }" class="min-h-screen flex items-center justify-center p-8">
    <div class="w-full max-w-md bg-white rounded-xl shadow-xl p-8">

        
        <div class="flex justify-center mb-4">
            <button
                :class="role === 'cliente' ? 'bg-purple-600 text-white' : 'bg-gray-100 text-gray-800'"
                class="px-4 py-2 rounded-l-lg font-semibold focus:outline-none"
                @click="role = 'cliente'">
                Cliente
            </button>
            <button
                :class="role === 'productor' ? 'bg-purple-600 text-white' : 'bg-gray-100 text-gray-800'"
                class="px-4 py-2 rounded-r-lg font-semibold focus:outline-none"
                @click="role = 'productor'">
                Productor
            </button>
        </div>

        
        <div class="text-center text-base text-gray-700 font-medium mb-6" x-cloak>
            <template x-if="role === 'cliente'">
                <span>
                    ¿Solo quieres comprar entradas?  
                    Regístrate como cliente para acceder a tus compras, recibir tus tickets y disfrutar de los eventos fácilmente.
                </span>
            </template>
            <template x-if="role === 'productor'">
                <span>
                    ¿Quieres organizar y vender tus propios eventos?  
                    Regístrate como productor para publicar, gestionar y controlar la venta de entradas de tus eventos.
                </span>
            </template>
        </div>

        <?php if($errors->any()): ?>
    <div class="mb-4 text-red-600">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>


        
        <form
            method="POST"
            action="<?php echo e(route('register')); ?>"
            class="space-y-6"
            @submit="loading = true"
        >
            <?php echo csrf_field(); ?>
            <input type="hidden" name="role" :value="role">

            
            <div>
                <label for="name" class="block text-sm font-medium text-gray-700">
                    <?php echo e(__('Nombre')); ?>

                </label>
                <input
                    id="name"
                    name="name"
                    type="text"
                    value="<?php echo e(old('name')); ?>"
                    required
                    autofocus
                    class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm
                        focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                >
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div>
                <label for="email" class="block text-sm font-medium text-gray-700">
                    <?php echo e(__('Correo electrónico')); ?>

                </label>
                <input
                    id="email"
                    name="email"
                    type="email"
                    value="<?php echo e(old('email')); ?>"
                    required
                    class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm
                        focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                >
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div x-show="role === 'productor'" x-transition>
                <label for="telefono" class="block text-sm font-medium text-gray-700">
                    Teléfono de contacto
                </label>
                <input
                    id="telefono"
                    name="telefono"
                    type="text"
                    class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm
                        focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                >
                
            </div>

            
            <div>
                <button
                    type="submit"
                    :disabled="loading"
                    class="w-full flex items-center justify-center py-2 px-4
                           bg-purple-600 hover:bg-purple-700 text-white font-semibold
                           rounded-md transition focus:outline-none focus:ring-2
                           focus:ring-purple-500 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    <!-- Texto normal -->
                    <span x-show="!loading" x-text="role === 'cliente' ? 'Crear cuenta como Cliente' : 'Crear cuenta como Productor'"></span>

                    <!-- Spinner + texto mientras carga -->
                    <span x-show="loading" class="flex items-center space-x-2">
                        <svg class="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"/>
                          <path class="opacity-75" fill="currentColor"
                                d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"/>
                        </svg>
                        <span>Cargando…</span>
                    </span>
                </button>
            </div>
        </form>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/ticketspro.online/resources/views/auth/register.blade.php ENDPATH**/ ?>