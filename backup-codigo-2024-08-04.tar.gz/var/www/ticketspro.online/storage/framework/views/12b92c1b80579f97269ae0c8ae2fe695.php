

<div class="space-y-10">

    
    <div class="rounded-2xl bg-white/90 border-l-8 border-purple-500 shadow-lg p-8 w-full">
        <div class="flex flex-col md:flex-row md:items-end md:justify-between gap-2 mb-4">
            <div>
                <h3 class="text-3xl font-extrabold text-purple-700 leading-none drop-shadow">
                    Recaudación global
                </h3>
                <div class="text-sm text-gray-500 font-semibold mt-1">
                    # Unidades vendidas
                </div>
            </div>
            <div class="flex flex-col items-end">
                <span class="text-4xl font-bold text-purple-700">
                    $<?php echo e(number_format(array_sum($recaudacionDiaria), 2)); ?>

                </span>
                <span class="text-base text-gray-400">total acumulado</span>
            </div>
        </div>

        <div class="mt-6">
            <!--[if BLOCK]><![endif]--><?php if(array_sum($recaudacionDiaria) > 0): ?>
            <div wire:ignore>
                <canvas id="recaudacionChart" height="120"></canvas>
            </div>
            <?php else: ?>
            <div class="text-gray-400 italic py-8 text-center">
                Todavía no tienes ventas suficientes para armar un gráfico.
            </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>

    
    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6 w-full">
        
        <div class="bg-gradient-to-br from-purple-100 to-white border-l-4 border-purple-400 rounded-xl shadow p-6 flex items-center gap-4">
            <div class="rounded-full bg-purple-50 text-purple-700 p-3 shadow-inner">
                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-qr-code'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-8 h-8']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
            </div>
            <div>
                <div class="text-lg font-bold text-purple-700">QRs generados</div>
                <div class="text-2xl font-extrabold text-gray-900"><?php echo e($qrsGenerados); ?></div>
            </div>
        </div>

        
        <div class="bg-gradient-to-br from-purple-100 to-white border-l-4 border-purple-400 rounded-xl shadow p-6 flex items-center gap-4">
            <div class="rounded-full bg-purple-50 text-purple-700 p-3 shadow-inner">
                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-check-circle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-8 h-8']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
            </div>
            <div>
                <div class="text-lg font-bold text-purple-700">QRs validados</div>
                <div class="text-2xl font-extrabold text-gray-900"><?php echo e($qrsEscaneados); ?></div>
            </div>
        </div>
    </div>

</div>

<?php $__env->startPush('scripts'); ?>
<?php if (! $__env->hasRenderedOnce('a91db31c-0cad-43e1-a168-11bba7694dab')): $__env->markAsRenderedOnce('a91db31c-0cad-43e1-a168-11bba7694dab'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<?php endif; ?>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        const ctx = document.getElementById('recaudacionChart');
        if (!ctx) return;

        new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($labels, 15, 512) ?>,
                datasets: [{
                    label: 'Recaudación ($)',
                    data: <?php echo json_encode(array_values($recaudacionDiaria), 15, 512) ?>,
                    borderColor: '#9333ea',
                    backgroundColor: 'rgba(147, 51, 234, 0.15)',
                    fill: true,
                    tension: 0.3,
                    pointRadius: 3,
                }],
            },
            options: {
                responsive: true,
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'Día'
                        },
                    },
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Total recaudado ($)'
                        },
                    },
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: ctx => `$ ${ctx.parsed.y.toLocaleString(undefined, { minimumFractionDigits: 2 })}`
                        }
                    }
                }
            }
        });
    });
</script>
<?php $__env->stopPush(); ?><?php /**PATH /var/www/ticketspro.online/resources/views/livewire/reportes-evento.blade.php ENDPATH**/ ?>