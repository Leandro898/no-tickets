
<?php if (isset($component)) { $__componentOriginal166a02a7c5ef5a9331faf66fa665c256 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panels::components.page.index','data' => ['class' => 'bg-violet-50 min-h-screen flex flex-col']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-panels::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-violet-50 min-h-screen flex flex-col']); ?>

    <div class="flex-1 flex flex-col items-center justify-center">

        <h2 class="text-violet-800 text-2xl font-bold mb-6 mt-4 text-center tracking-tight">
            Enfocá el código QR
        </h2>

        <div class="bg-white rounded-2xl shadow-xl flex flex-col items-center p-4"
            style="min-width:320px; max-width:95vw;">
            <div
                class="relative aspect-square w-72 sm:w-80 md:w-96 rounded-xl overflow-hidden border-4 border-violet-500 flex items-center justify-center">
                <div id="reader" class="w-full h-full"></div>
            </div>
        </div>

        <div class="mt-8 text-center space-y-3">
            <button id="btnManualInput" type="button"
                class="font-semibold text-violet-700 hover:underline text-base bg-transparent border-none">
                Ingresar datos manualmente
            </button>
            <div class="text-gray-500 text-sm h-12">
                
                
            </div>
            
        </div>
    </div>

    <script>
        window.csrfToken = "<?php echo e(csrf_token()); ?>";
        window.buscarTicketEndpoint  = "<?php echo e(route('admin.ticket-scanner.buscar')); ?>";
        window.validarTicketEndpoint = "<?php echo e(route('admin.ticket-scanner.validar')); ?>";
    </script>

    <?php echo app('Illuminate\Foundation\Vite')('resources/js/scanner/index.js'); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $attributes = $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $component = $__componentOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php /**PATH /var/www/ticketspro.online/resources/views/filament/pages/ticket-scanner.blade.php ENDPATH**/ ?>