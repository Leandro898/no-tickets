<?php $__env->startSection('title', 'Ingresar'); ?>


<?php $__env->startSection('body-class', 'bg-gradient-to-br from-purple-50 to-purple-100'); ?>

<?php $__env->startSection('content'); ?>
<div class="min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
  <div class="max-w-md w-full bg-white shadow-xl rounded-xl p-8">
    <h2 class="text-2xl font-extrabold text-gray-900 mb-6 text-center">
      Ingresar
    </h2>

    
    <?php if($errors->any()): ?>
      <div class="mb-4 text-red-600 text-sm">
        <ul class="list-disc list-inside">
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('login')); ?>" class="space-y-6">
      <?php echo csrf_field(); ?>

      
      <div>
        <label for="email" class="block text-sm font-medium text-gray-700">
          Email
        </label>
        <input
          id="email"
          name="email"
          type="email"
          value="<?php echo e(old('email')); ?>"
          required
          autofocus
          class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm
                 focus:outline-none focus:ring-purple-500 focus:border-purple-500"
        />
      </div>

      
      <div>
        <label for="password" class="block text-sm font-medium text-gray-700">
          Password
        </label>
        <input
          id="password"
          name="password"
          type="password"
          required
          class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm
                 focus:outline-none focus:ring-purple-500 focus:border-purple-500"
        />
      </div>

      
      <div class="flex items-center justify-between">
        <label class="inline-flex items-center text-sm text-gray-700">
          <input
            type="checkbox"
            name="remember"
            class="rounded text-purple-600 focus:ring-purple-500 border-gray-300"
          />
          <span class="ml-2">Mantener conectado</span>
        </label>

        <?php if(Route::has('password.request')): ?>
          <a
            href="<?php echo e(route('password.request')); ?>"
            class="text-sm text-purple-700 hover:underline"
          >
            Olvidaste tu contraseña?
          </a>
        <?php endif; ?>
      </div>

      
      <div>
        <button
          type="submit"
          class="w-full flex justify-center py-2 px-4 bg-purple-600 hover:bg-purple-700
                 text-white font-semibold rounded-md transition focus:outline-none
                 focus:ring-2 focus:ring-offset-2 focus:ring-purple-500"
        >
          Ingresar
        </button>
      </div>
    </form>

    
    <p class="mt-6 text-center text-sm text-gray-600">
      ¿No tienes cuenta?
      <a
        href="<?php echo e(route('register')); ?>"
        class="text-purple-700 hover:underline"
      >
        Registrar
      </a>
    </p>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/ticketspro.online/resources/views/auth/login.blade.php ENDPATH**/ ?>