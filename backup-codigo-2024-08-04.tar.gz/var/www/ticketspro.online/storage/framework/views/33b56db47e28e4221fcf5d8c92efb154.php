<?php $__env->startSection('title', $evento->nombre.' – Detalles del Evento'); ?>


<?php $__env->startSection('body-class', 'bg-gradient-to-br from-purple-50 min-h-screen overflow-y-scroll'); ?>

<?php $__env->startPush('styles'); ?>
  <style>
    /* Quitar flechas de inputs numéricos */
    input[type=number]::-webkit-inner-spin-button,
    input[type=number]::-webkit-outer-spin-button {
      -webkit-appearance: none;
      margin: 0;
    }
    input[type=number] {
      -moz-appearance: textfield;
    }
  </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
  <div class="max-w-7xl mx-auto px-4 pt-6 pb-8">

    
    <div class="flex justify-end mb-4">
      <a href="/"
         class="inline-flex items-center gap-2 bg-white hover:bg-purple-50 border border-purple-200
                text-purple-700 font-semibold px-4 py-2 rounded-lg shadow transition">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none"
             viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                d="M15 19l-7-7 7-7" />
        </svg>
        Volver a eventos
      </a>
    </div>

    
    <h1 class="text-3xl sm:text-4xl font-extrabold text-purple-700 text-center mb-6">
      <?php echo e($evento->nombre); ?>

    </h1>

    <div class="flex flex-col lg:flex-row items-start gap-8">
      
      <div class="w-full lg:w-1/2 space-y-6">
        
        <div class="flex justify-center">
          <?php if($evento->imagen): ?>
            <img
              src="<?php echo e(asset('storage/'.$evento->imagen)); ?>"
              alt="Banner de <?php echo e($evento->nombre); ?>"
              class="w-full max-w-xs md:max-w-sm object-contain rounded-lg shadow-lg"
            />
          <?php else: ?>
            <div class="w-64 h-40 bg-gray-100 flex items-center justify-center rounded-lg shadow-lg">
              <span class="text-gray-400">Sin imagen disponible</span>
            </div>
          <?php endif; ?>
        </div>

        
        <div class="bg-white rounded-2xl p-6 shadow-lg">
          <h2 class="text-2xl font-bold text-purple-700 mb-3">Acerca del evento</h2>
          <p class="text-gray-800"><?php echo e($evento->descripcion); ?></p>
        </div>
      </div>

      
      <div class="w-full lg:w-1/2 space-y-6" x-data>
        
        <div class="text-center">
          <span id="countdown"
                class="inline-block bg-purple-600 text-white font-semibold px-5 py-3 rounded-lg shadow-lg">
            Cargando…
          </span>
        </div>

        
        <div class="flex justify-center">
          <div class="bg-purple-600 text-white rounded-xl p-2 text-center shadow max-w-xs w-full">
            <div class="text-xs sm:text-sm font-medium">Entradas desde</div>
            <div class="text-lg sm:text-xl font-extrabold my-0.5">
              $<?php echo e(number_format($evento->entradas->min('precio'), 0, ',', '.')); ?>

            </div>
          </div>
        </div>

        
        <?php $__currentLoopData = $evento->entradas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entrada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($entrada->stock_actual > 0): ?>
            <form action="<?php echo e(route('eventos.comprar.split.store', $evento)); ?>"
                  method="POST" x-data="{ qty: 1 }"
                  class="bg-white rounded-xl p-5 shadow border border-purple-100">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="entrada_id" value="<?php echo e($entrada->id); ?>">

              
              <div class="text-sm font-bold text-gray-700 mb-2">
                <?php echo e(\Carbon\Carbon::parse($evento->fecha_inicio)
                     ->locale('es')
                     ->translatedFormat('l d \\d\\e F, H:i')); ?> hs
              </div>

              
              <div class="flex justify-between items-center mb-4">
                <div class="text-lg font-semibold text-gray-800"><?php echo e($entrada->nombre); ?></div>
                <div class="text-lg font-bold text-gray-900">
                  $<?php echo e(number_format($entrada->precio, 0, ',', '.')); ?>

                </div>
              </div>

              
              <div class="flex justify-center items-center space-x-4 mb-4">
                <button type="button" @click="qty = Math.max(1, qty - 1)"
                        class="w-10 h-10 bg-purple-100 hover:bg-purple-200 rounded-lg text-purple-700 font-bold text-xl">
                  −
                </button>
                <input type="number" name="cantidad" x-model.number="qty"
                       min="1" max="<?php echo e($entrada->stock_actual); ?>"
                       class="w-16 h-10 text-center border border-gray-300 rounded-lg" />
                <button type="button"
                        @click="qty = Math.min(<?php echo e($entrada->stock_actual); ?>, qty + 1)"
                        class="w-10 h-10 bg-purple-100 hover:bg-purple-200 rounded-lg text-purple-700 font-bold text-xl">
                  +
                </button>
              </div>

              
              <div class="flex justify-between items-center">
                <div class="text-gray-700 font-medium">
                  Total:
                  <span class="font-bold"
                        x-text="`$${(qty * <?php echo e($entrada->precio); ?>).toLocaleString('de-DE')}`">
                  </span>
                </div>
                <button type="submit"
                        class="bg-green-500 hover:bg-green-600 text-white font-extrabold text-lg px-6 py-3 rounded-full">
                  Comprar
                </button>
              </div>
            </form>
          <?php else: ?>
            
            <div class="bg-red-50 text-red-600 rounded-xl p-5 shadow border border-red-100 text-center">
              Entradas de <strong><?php echo e($entrada->nombre); ?></strong> agotadas.
            </div>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
  
  <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>

  
  <script>
    (function(){
      const target = new Date("<?php echo e(\Carbon\Carbon::parse($evento->fecha_inicio)->format('Y/m/d H:i:s')); ?>").getTime();
      const el = document.getElementById('countdown');
      function update() {
        const now = Date.now();
        const diff = target - now;
        if (diff <= 0) {
          el.textContent = '¡El evento ha comenzado!';
          clearInterval(timer);
          return;
        }
        const d = Math.floor(diff / 86400000);
        const h = Math.floor((diff % 86400000) / 3600000);
        const m = Math.floor((diff % 3600000) / 60000);
        const s = Math.floor((diff % 60000) / 1000);
        el.textContent = `Faltan ${d} d | ${h} h | ${m} m | ${s} s`;
      }
      update();
      const timer = setInterval(update, 1000);
    })();
  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/ticketspro.online/resources/views/eventos/show.blade.php ENDPATH**/ ?>