<?php $__env->startSection('body-class','bg-gradient-to-br from-purple-50 to-purple-100 min-h-screen flex flex-col'); ?>

<?php $__env->startSection('content'); ?>
  <div class="flex flex-1 items-center justify-center px-2">
    <div class="w-full max-w-4xl bg-white rounded-[95px] shadow-2xl px-6 sm:px-14 md:px-20 py-10 mx-auto mb-12">

      
      <div class="bg-violet-50 border-l-4 border-violet-500 rounded-2xl px-7 py-6 mb-10 shadow flex flex-col gap-3">
        <div class="flex items-center gap-3 mb-2">
          <svg class="w-6 h-6 text-violet-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                  d="M12 8v4l3 3M4 4h16v16H4V4z" />
          </svg>
          <span class="text-lg font-semibold text-violet-700">Resumen de tu compra</span>
        </div>
        <div class="flex justify-between items-center text-gray-700 text-base py-1">
          <span class="font-medium">Entrada:</span>
          <span><?php echo e($entrada->nombre); ?></span>
        </div>
        <div class="flex justify-between items-center text-gray-700 text-base py-1">
          <span class="font-medium">Cantidad:</span>
          <span><?php echo e($cantidad); ?></span>
        </div>
        <div class="flex justify-between items-center text-gray-900 text-xl font-extrabold pt-3">
          <span>Subtotal:</span>
          <span>$<?php echo e(number_format($subtotal, 0, ',', '.')); ?></span>
        </div>
      </div>

      
      <form action="<?php echo e(route('eventos.comprar.split.storeDatos', $evento)); ?>"
            method="POST"
            class="space-y-8">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="entrada_id" value="<?php echo e($entrada->id); ?>">
        <input type="hidden" name="cantidad"    value="<?php echo e($cantidad); ?>">

        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
          
          <div class="space-y-6">
            <div>
              <label for="nombre" class="block text-sm font-medium text-gray-700 mb-1">
                Nombre completo <span class="text-red-500">*</span>
              </label>
              <input id="nombre" name="nombre" type="text" required
                     class="w-full rounded-lg border border-gray-300 px-4 py-3 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-purple-200 focus:border-transparent" />
            </div>
            <div>
              <label for="buyer_dni" class="block text-sm font-medium text-gray-700 mb-1">
                DNI (opcional)
              </label>
              <input id="buyer_dni" name="buyer_dni" type="text"
                     class="w-full rounded-lg border border-gray-300 px-4 py-3 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-purple-200 focus:border-transparent" />
            </div>
          </div>

          
          <div class="space-y-6">
            <div>
              <label for="email" class="block text-sm font-medium text-gray-700 mb-1">
                Email <span class="text-red-500">*</span>
              </label>
              <input id="email" name="email" type="email" required
                     class="w-full rounded-lg border border-gray-300 px-4 py-3 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-purple-200 focus:border-transparent" />
            </div>
            <div>
              <label for="whatsapp" class="block text-sm font-medium text-gray-700 mb-1">
                WhatsApp (opcional)
              </label>
              <div class="flex">
                <span class="inline-flex items-center px-3 rounded-l-lg border border-r-0 border-gray-300 bg-white text-gray-600">
                  +54
                </span>
                <input id="whatsapp" name="whatsapp" type="text" placeholder="2944 123456"
                       class="flex-1 rounded-r-lg border border-gray-300 px-4 py-3 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-purple-200 focus:border-transparent" />
              </div>
            </div>
          </div>
        </div>

        
        <p class="text-center text-sm text-gray-500 mb-2">
          Al finalizar, te enviaremos las entradas por <strong>Correo</strong>.
        </p>

        
        <button type="submit"
                class="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-4 rounded-xl transition-shadow shadow-md hover:shadow-lg text-lg tracking-wide mt-2 mb-1">
          Proceder al pago
        </button>
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/ticketspro.online/resources/views/comprar-entrada-datos.blade.php ENDPATH**/ ?>