<header class="bg-white shadow w-full sticky top-0 z-50">
    <div class="container mx-auto px-4 sm:px-8 lg:px-12 py-3 flex justify-between items-center">
        <a href="<?php echo e(url('/')); ?>"
           class="text-2xl font-extrabold text-purple-700 sm:text-3xl whitespace-nowrap tracking-tight leading-none">
            Tickets Pro
        </a>

        
        <nav class="hidden md:flex items-center space-x-3 sm:space-x-7 lg:space-x-10 nav-desktop">
            <a href="/"
               class="text-gray-700 hover:text-purple-700 font-medium text-lg px-2 py-1 rounded transition-all duration-150 hover:underline hover:underline-offset-8 hover:decoration-2">
                Eventos
            </a>

            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('mis-entradas')); ?>"
                   class="text-gray-700 hover:text-purple-700 font-medium text-lg px-2 py-1 rounded transition-all duration-150 hover:underline hover:underline-offset-8 hover:decoration-2">
                    Mis Entradas
                </a>
            <?php endif; ?>

            <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(route('login')); ?>"
                   class="text-gray-700 hover:text-purple-700 font-medium text-lg px-2 py-1 rounded transition-all duration-150">
                    Ingresar
                </a>
                <a href="<?php echo e(route('register')); ?>"
                   class="text-gray-700 hover:text-purple-700 font-medium text-lg px-2 py-1 rounded transition-all duration-150">
                    Registrar
                </a>
            <?php endif; ?>
        </nav>

        
        <?php if(auth()->guard()->check()): ?>
            <div class="relative ml-4" x-data="{ open: false }">
                <button @click="open = !open"
                        class="flex items-center text-gray-700 hover:text-purple-700 font-medium text-lg px-2 py-1 rounded transition-all duration-150 focus:outline-none">
                    <span class="mr-1 truncate max-w-[120px] sm:max-w-none"><?php echo e(Auth::user()->name); ?></span>
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                    </svg>
                </button>
                <div x-show="open" @click.away="open = false"
                     class="absolute right-0 mt-2 w-44 bg-white border rounded shadow-lg py-2 z-50"
                     x-cloak>
                    <a href="<?php echo e(route('profile.edit')); ?>"
                       class="block px-4 py-2 text-gray-700 hover:bg-gray-100">Perfil</a>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit"
                                class="w-full text-left block px-4 py-2 text-gray-700 hover:bg-gray-100">
                            Cerrar Sesión
                        </button>
                    </form>
                </div>
            </div>
        <?php endif; ?>

        
        <?php if(auth()->guard()->guest()): ?>
            <nav class="flex md:hidden items-center space-x-4 nav-mobile">
                <a href="<?php echo e(route('login')); ?>"
                   class="text-gray-700 hover:text-purple-700 font-medium text-base px-1 py-1 rounded transition-all duration-150">
                    Ingresar
                </a>
                <a href="<?php echo e(route('register')); ?>"
                   class="text-gray-700 hover:text-purple-700 font-medium text-base px-1 py-1 rounded transition-all duration-150">
                    Registrar
                </a>
            </nav>
        <?php endif; ?>
    </div>

    <style>
        .nav-desktop {
            display: none;
        }
        @media (min-width: 768px) {
            .nav-desktop {
                display: flex !important;
            }
            .nav-mobile {
                display: none !important;
            }
        }
    </style>
</header>
<?php /**PATH /var/www/ticketspro.online/resources/views/layouts/front-nav.blade.php ENDPATH**/ ?>