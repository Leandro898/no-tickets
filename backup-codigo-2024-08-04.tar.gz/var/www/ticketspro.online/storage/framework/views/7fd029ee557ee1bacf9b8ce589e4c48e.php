<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_','-',app()->getLocale())); ?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title><?php echo $__env->yieldContent('title', config('app.name')); ?></title>
  <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('favicon/tickets-pro.png')); ?>">
  <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
  
  <?php echo $__env->yieldPushContent('styles'); ?>
  <!-- <style>
    html { overflow-y: scroll; }
  </style> -->
</head>
<body class="<?php echo $__env->yieldContent('body-class', 'bg-purple-50 min-h-screen flex flex-col overflow-y-scroll'); ?>">

  
  <?php echo $__env->make('layouts.front-nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  
  <?php echo $__env->yieldContent('slider'); ?>

  
  <main class="flex-1 container mx-auto px-4 sm:px-6 lg:px-8 py-8">
    <?php echo $__env->yieldContent('content'); ?>
  </main>

  
  <footer class="bg-gray-900 text-gray-300 text-sm py-6">
    <div class="container mx-auto text-center space-y-2">
      <p>© <?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?>. Todos los derechos reservados.</p>
      <div class="flex justify-center gap-4">
        <a href="#" class="hover:text-white">Política de privacidad</a>
        <a href="#"   class="hover:text-white">Términos de uso</a>
        <a href="#" class="hover:text-white">Contacto</a>
      </div>
    </div>
  </footer>

  <?php echo $__env->yieldPushContent('scripts'); ?>

  <!-- Alpine.js para dropdowns y otros componentes -->
  <script src="//unpkg.com/alpinejs" defer></script>
  
  <?php echo $__env->make('components.front-floating-menu', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  
</body>
</html>
<?php /**PATH /var/www/ticketspro.online/resources/views/layouts/app.blade.php ENDPATH**/ ?>